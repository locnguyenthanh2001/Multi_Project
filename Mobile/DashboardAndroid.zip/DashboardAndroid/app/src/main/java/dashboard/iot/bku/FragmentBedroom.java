package dashboard.iot.bku;

import android.content.Intent;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;




//import static dashboard.iot.bku.Constants.BEDROOM_FRAGMENT_INDEX;
//import static dashboard.iot.bku.Constants.LIVINGROOM_FRAGMENT_INDEX;

/**
 * Created by ADMIN on 3/17/2022.
 */

import android.support.v7.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class FragmentBedroom  extends AppCompatActivity {
   TextView txtTemp, txtHumi, txtpH;
   String temperature = "25", humidity = "93", pH = "7";
    Bundle data;
    MQTTHelper mqttHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_fragment_bedroom);

        txtTemp =  findViewById(R.id.Temperature);
        txtHumi = findViewById(R.id.Humidity);
        txtpH   =  findViewById(R.id.pH);

        data = getIntent().getExtras();
        if (data != null) {
            temperature = data.getString("temperature");
            //The key argument here must match that used in the other activity
            txtTemp.setText(temperature + "°C");
            humidity = data.getString("humidity");
            //The key argument here must match that used in the other activity
            txtHumi.setText(humidity + "%");
            pH = data.getString("pH");
            //The key argument here must match that used in the other activity
            txtpH.setText(pH);
        }
        startMQTT();
    }

    private void startMQTT() {
        mqttHelper = new MQTTHelper(getApplicationContext(), "123456");

        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d("mqtt", "Connection is successful");
            }

            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.d("mqtt", "Received: " + topic + message.toString());
//                String id = "";
//                val = decode(message.toString());
//                id += message.toString().charAt(0);
                if(topic.equals("locthanh2001/feeds/temp") ){
                    temperature = message.toString();
                    txtTemp.setText(temperature + "°C");
                    data.putString("temperature", temperature);

                }
                if(topic.equals("locthanh2001/feeds/humid")){
                    humidity = message.toString();
                    txtHumi.setText(humidity + "%");
                    data.putString("temperature", humidity);
                }
                if(topic.equals("locthanh2001/feeds/tds")){
                    pH = message.toString();
                    txtpH.setText(pH);
                    data.putString("temperature", pH);
//                    fragmentBedRoom.pH = message.toString();
//                    if(fragment == fragmentBedRoom) {
//                        fragmentBedRoom.txtpH.setText(fragmentBedRoom.pH);
//                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });
    }
}
