package dashboard.iot.bku;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.WindowManager;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    Button btnLiv, btnBed, btnKit;
    Intent BEDROOM, LIVINGROOM, KITCHEN;
    Intent intent;
    //TextView Temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        BEDROOM = new Intent(this, FragmentBedroom.class);
        LIVINGROOM = new Intent(this, FragmentLivingroom.class);
        KITCHEN = new Intent(this, FragmentKitchen.class);

        btnBed = findViewById(R.id.btnBedroom);
        btnBed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(1);
            }
        });

        btnLiv = findViewById(R.id.btnLivingroom);
        btnLiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(2);
            }
        });

        btnKit = findViewById(R.id.btnKitchen);
        btnKit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(3);
            }
        });

        //Temp =  findViewById(R.id.Temperature);

    }

    public void openNewActivity(int select){
        switch (select){
            case 1:
                intent = BEDROOM;
                break;
            case 2:
                intent = LIVINGROOM;
                break;
            case 3:
                intent = KITCHEN;
                break;
            default:
                break;
        }
        try {
            startActivity(intent);
        } catch (Exception e) {

        }
    }

    //Dung de tu fragment giao tiep vs
    public void proccessDataFromFragment(int fragment_index, String fragment_data){
        Log.d("Fragment", "Data is from: " + fragment_index);
        Log.d("Fragment", "Value: " + fragment_data);
    }

    //1:34
    public String decode(String message){
        String temp = "";
        for(int i = 2; i < message.length(); i++){
            temp += message.charAt(i);
        }
        return temp;
    }
}
