package dashboard.iot.bku;

/**
 * Created by ADMIN on 2/21/2022.
 */

public class Constants {
    public static final int LIVINGROOM_FRAGMENT_INDEX = 1;
    public static final int BEDROOM_FRAGMENT_INDEX = 2;
    public static final int KITCHEN_FRAGMENT_INDEX = 3;

}
